package com.home.hotel.booking.dao;
import java.util.List;
import com.home.hotel.booking.model.Reservation;

public interface ReservationDao {
	int insertReservation(Reservation res);
	List<Reservation> getAllReservations();
}
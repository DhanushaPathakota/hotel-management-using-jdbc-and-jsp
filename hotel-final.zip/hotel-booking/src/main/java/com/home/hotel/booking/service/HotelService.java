package com.home.hotel.booking.service;
import java.util.List;

import com.home.hotel.booking.model.Hotel;


public interface HotelService {
	void insertHotel(Hotel hot);
	List<Hotel> getAllHotel();
	void deleteHotel(Hotel hot);
	void updateHotel(Hotel hot);
	List<Hotel> findHotel(Hotel hot);
   boolean isPresent(Hotel hot);
}


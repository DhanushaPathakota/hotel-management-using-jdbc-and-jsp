package com.home.hotel.booking.model;

public class Hotel {
	   String hotelId;
	String hotelName;
    String address;
    String rating;
 

    public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String name) {
		this.hotelName = name;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String addr) {
		this.address = addr;
	}
public String getRating()
{
	return rating;
}
public void setRating(String rate)
{
	this.rating=rate;
	}
@Override
public String toString() {
	return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ",addr=" + address +  "]";
	
}

}

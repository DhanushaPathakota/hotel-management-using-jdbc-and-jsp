package com.home.hotel.booking.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.hotel.booking.dao.ReservationDao;
import com.home.hotel.booking.model.Reservation;
import com.home.hotel.booking.service.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService {
	@Autowired
	ReservationDao reservationDao;

	public int insertReservation(Reservation res) {
		return reservationDao.insertReservation(res);
	}

	public List<Reservation> getAllReservations() {
		return reservationDao.getAllReservations();
	}

	
}

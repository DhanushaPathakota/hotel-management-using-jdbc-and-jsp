package com.home.hotel.booking.service;
import java.util.List;

import com.home.hotel.booking.model.Reservation;

public interface ReservationService {
	int insertReservation(Reservation res);
	List<Reservation> getAllReservations();
}

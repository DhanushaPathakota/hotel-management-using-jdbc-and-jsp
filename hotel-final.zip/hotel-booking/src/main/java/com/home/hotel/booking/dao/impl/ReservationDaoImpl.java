package com.home.hotel.booking.dao.impl;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;

import com.home.hotel.booking.dao.ReservationDao;
import com.home.hotel.booking.model.Hotel;
import com.home.hotel.booking.model.Reservation;

@Repository
public class ReservationDaoImpl extends JdbcDaoSupport implements ReservationDao{
	
	@Autowired 
	DataSource dataSource;
	
	@PostConstruct
	private void initialize(){
		setDataSource(dataSource);
	}
	
	public int insertReservation(Reservation res) {
		Connection con=null;
		int flag=0;
		List<Map<String, Object>> row = getJdbcTemplate().queryForList("select * from hotel where hotelName=?", new Object[]{res.gethotelName()});
		if(row==null||row.isEmpty())
		{
			flag=-1;
			return flag;
		}

		try {
		
		
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project?serverTimezone=UTC","root","");
				String query="select * from reservation";
				Statement stmt=con.createStatement();
				ResultSet rs=stmt.executeQuery(query);

				while(rs.next()) {
					
					if(rs.getString("HotelName").equals(res.gethotelName()) && rs.getString("Roomno").equals(res.getroomno()) && rs.getString("booked").equals("true") ) {
		
						flag=1;
						
					}
				}
				
					if (flag==1)
					{
						
						return flag;
					
					}
	else {
						res.setBooked("true");
						String sql = "INSERT INTO reservation VALUES (?,?,?,?,?,?)" ;
					getJdbcTemplate().update(sql, new Object[]{
							res.gethotelName(),res.getguests(),res.getroomno(),res.getUserName(),res.getPhoneno(),res.getBooked()
							
					});					
					}				
				
				
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
		//return new ModelAndView("validate");
/*	if(flag==1)
	{
		return ModelAndView("validate");
	}
	}*/
	}
		

	public List<Reservation> getAllReservations(){
		String sql = "SELECT * FROM reservation";	
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
		
		List<Reservation> result = new ArrayList<Reservation>();
		for(Map<String, Object> row:rows){
			Reservation res = new Reservation();
			res.sethotelName((String)row.get("HotelName"));
			res.setguests((String) row.get("guests"));
			res.setRoomno((String)row.get("Roomno"));
			res.setUserName((String)row.get("userName"));
			res.setPhoneno((String)row.get("phoneno"));
//System.out.println(res);
			result.add(res);
		}
		
		return result;
	}

}

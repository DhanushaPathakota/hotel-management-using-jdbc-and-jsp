package com.home.hotel.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.home.hotel.booking.model.Hotel;
import com.home.hotel.booking.model.Reservation;
import com.home.hotel.booking.service.HotelService;


@Controller
public class HotelController {
	@Autowired
	HotelService hotelService;
	
	@RequestMapping("/welcome")
	public ModelAndView firstPage() {
		return new ModelAndView("welcome");
	}
	
	@RequestMapping(value = "/addHotel", method = RequestMethod.GET)
	public ModelAndView show() {
		return new ModelAndView("addHotel", "hot", new Hotel());
	}
	
	@RequestMapping(value = "/addHotel", method = RequestMethod.POST)
	public ModelAndView processRequest(@ModelAttribute("hot") Hotel hot) {
		hotelService.insertHotel(hot);
		List<Hotel> hotels = hotelService.getAllHotel();
		ModelAndView model = new ModelAndView("addHotel");
		model.addObject("hotels", hotels);
		return model;
	}
	
	@RequestMapping("/getHotel")
	public ModelAndView getHotel() {
		List<Hotel> hotels = hotelService.getAllHotel();
		ModelAndView model = new ModelAndView("getHotel");
		model.addObject("hotels",hotels);
		return model;
	}
	
	@RequestMapping(value = "/deleteHotel", method = RequestMethod.GET)
	public ModelAndView del() {
		return new ModelAndView("deleteHotel", "hot", new Hotel());
	}
	@RequestMapping(value = "/deleteHotel", method = RequestMethod.POST)
	public ModelAndView processDelete(@ModelAttribute("hot") Hotel hot) {
		if(hotelService.isPresent(hot))
		{
		hotelService.deleteHotel(hot);
		List<Hotel> hotels = hotelService.getAllHotel();
		ModelAndView model = new ModelAndView("deleteHotel");
		model.addObject("hotels", hotels);
		return model;
	}
	return new ModelAndView("validate");
	}
	@RequestMapping(value = "/updateHotel", method = RequestMethod.GET)
	public ModelAndView up() {
		return new ModelAndView("updateHotel", "hot", new Hotel());
	}
	@RequestMapping(value = "/updateHotel", method = RequestMethod.POST)
	public ModelAndView processUpdate(@ModelAttribute("hot") Hotel hot) {
		
		if(hotelService.isPresent(hot))
		{
		hotelService.updateHotel(hot);
		List<Hotel> hotels = hotelService.getAllHotel();
		ModelAndView model = new ModelAndView("updateHotel");
		model.addObject("hotels",hotels);
		return model;
		}
		return new ModelAndView("validate");
	}

	@RequestMapping(value="/findHotel",method = RequestMethod.GET)
	public ModelAndView FindHotel(@ModelAttribute("hot") Hotel hot) {
		hotelService.findHotel(hot);
		List<Hotel> hotels = hotelService.getAllHotel();
		ModelAndView model = new ModelAndView("findHotel");
		model.addObject("hotels", hotels);
		return model;
		}
		
}
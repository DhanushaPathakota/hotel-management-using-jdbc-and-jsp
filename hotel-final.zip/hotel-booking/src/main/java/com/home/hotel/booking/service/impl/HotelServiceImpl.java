package com.home.hotel.booking.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.hotel.booking.dao.HotelDao;
import com.home.hotel.booking.model.Hotel;
import com.home.hotel.booking.service.HotelService;

@Service
public class HotelServiceImpl implements HotelService {
	
	@Autowired
	HotelDao hotelDao;

	@Override
	public void insertHotel(Hotel hot) {
		hotelDao.insertHotel(hot);
		
	}

	@Override
	public List<Hotel> getAllHotel() {
		return hotelDao.getAllHotel();
	}

	@Override
	public void deleteHotel(Hotel hot) {
		hotelDao.deleteHotel(hot);
		
	}

	@Override
	public void updateHotel(Hotel hot) {
		hotelDao.updateHotel(hot);
		
	}

	@Override
	public List<Hotel> findHotel(Hotel hot) {
		return hotelDao.findHotel(hot);
	}
	
public boolean isPresent(Hotel hot)
{
	return hotelDao.isPresent(hot);
}
}

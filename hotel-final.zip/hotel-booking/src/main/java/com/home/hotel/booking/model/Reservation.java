package com.home.hotel.booking.model;

import java.util.*;
public class Reservation {
String HotelName;
String guests;
String Roomno;
String userName;
String phoneno;
String booked="false";

	public String gethotelName() {
		return 	HotelName;
	}
	public void sethotelName(String hotelName) {
		this.HotelName = hotelName;
	}
	

	public String getguests() {
		return guests;
	}
	public void setguests(String guest) {
		this.guests = guest;
	}  
	
	public String getroomno() {
		return Roomno;
	}
	public void setRoomno(String no) {
		this.Roomno = no;
	}  
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName =userName;
	}
	
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	
	public String getBooked() {
		return booked;
	}
	public void setBooked(String book) {
		this.booked =book;
	}
	
}

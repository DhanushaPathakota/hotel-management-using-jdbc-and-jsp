package com.home.hotel.booking.controller;




import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.home.hotel.booking.model.Reservation;
import com.home.hotel.booking.service.ReservationService;

@Controller
public class ReservationController {
	@Autowired
	ReservationService reservationService;



    //show the add resie form and also pass an empty backing bean object to store the form field values
	@RequestMapping(value = "/addNewReservation", method = RequestMethod.GET)
	public ModelAndView show() {
		return new ModelAndView("addNewReservation", "res", new Reservation());
	}

    //Get the form field values which are populated using the backing bean and store it in db
	@RequestMapping(value = "/addNewReservation", method = RequestMethod.POST)
	public ModelAndView processRequest(@ModelAttribute("res") Reservation res) {
		int flag = reservationService.insertReservation(res);
		List<Reservation> reservations = reservationService.getAllReservations();
		ModelAndView model = new ModelAndView("success");
		model.addObject("reservations",reservations);
		if (flag == 1) {
			return new ModelAndView("errorAddition");
		}
		if(flag==-1)
		{
			return new ModelAndView("validate");
		}
		return model;
	}

    //show all resies saved in db
	@RequestMapping("/getReservations")
	public ModelAndView getReservations() {
		List<Reservation>reservations = reservationService.getAllReservations();
		ModelAndView model = new ModelAndView("getReservations");
		model.addObject("reservations",reservations);
		return model;
	}


}

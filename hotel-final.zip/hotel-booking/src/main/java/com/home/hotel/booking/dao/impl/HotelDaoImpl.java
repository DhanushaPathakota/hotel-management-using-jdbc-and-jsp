package com.home.hotel.booking.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.home.hotel.booking.dao.HotelDao;
import com.home.hotel.booking.model.Hotel;


@Repository
public class HotelDaoImpl extends JdbcDaoSupport implements HotelDao{
	
	@Autowired 
	DataSource dataSource;
	
	@PostConstruct
	private void initialize(){
		setDataSource(dataSource);
	}

	@Override
	public void insertHotel(Hotel hot) {
		String sql = "insert into hotel(hotelId,hotelName,address,rating) values (?,?,?,?)";
		getJdbcTemplate().update(sql, new Object[]{
				hot.getHotelId(), hot.getHotelName(), hot.getAddress(), hot.getRating()
		});
	}

	@Override
	public List<Hotel> getAllHotel() {
		String sql = "SELECT * FROM hotel";
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
		
		List<Hotel> result = new ArrayList<Hotel>();
		for(Map<String, Object> row:rows) {
			Hotel hot=new Hotel();
			hot.setHotelId((String)row.get("hotelId"));
			hot.setHotelName((String)row.get("hotelName"));
			hot.setAddress((String)row.get("address"));
			hot.setRating((String)row.get("rating"));
		
			
			result.add(hot);
		}
		return result;
	}

	@Override
	public void deleteHotel(Hotel hot) {
		String sql = "DELETE FROM hotel Where hotelName = ?" ;
		getJdbcTemplate().update(sql, new Object[]{
				hot.getHotelName()
		});
		
	}

	@Override
	public void updateHotel(Hotel hot) {
		getJdbcTemplate().update("update hotel set rating= ? where hotelName = ?",
				new Object[] {hot.getRating(),hot.getHotelName()});
		
	}

	@Override
	public List<Hotel> findHotel(Hotel hot) {
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList("select * from hotel where hotelName=?", new Object[]{hot.getHotelName()});
		List<Hotel> result = new ArrayList<Hotel>();
		for(Map<String, Object> row:rows) {
			Hotel hot1 = new Hotel();
			hot1.setHotelName((String)row.get("hotelName"));
			hot.setHotelId((String)row.get("hotelId"));
			hot.setAddress((String)row.get("address"));
			hot.setRating((String)row.get("rating"));
			result.add(hot);
		}
		return result;
	}
public boolean isPresent(Hotel hot)
{
	List<Map<String, Object>> rows = getJdbcTemplate().queryForList("select * from hotel where hotelName=?", new Object[]{hot.getHotelName()});
	if(rows==null||rows.isEmpty())
		return false;
	return true;
}
}

	
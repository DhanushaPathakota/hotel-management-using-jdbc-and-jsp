DROP TABLE IF EXISTS hotel;

CREATE TABLE hotel (
  hotelId VARCHAR(100) ,
  hotelName VARCHAR(100) NOT NULL
);